Muki Web Demo
Files:
- index.html
- style.css
- script.js

How to use:
1. Upload these files to your GitHub repository root (use Upload files).
2. In repo Settings -> Pages, set source to main branch / root and Save.
3. Visit https://<your-username>.github.io/<repo-name>
